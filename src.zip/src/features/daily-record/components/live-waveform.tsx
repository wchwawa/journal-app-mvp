'use client';

import { useEffect, useRef } from 'react';
import { cn } from '@/lib/utils';

type LiveWaveformProps = {
  stream: MediaStream | null;
  isActive: boolean;
  className?: string;
  waveColor?: string;
  height?: number;
};

/**
 * Renders a real-time waveform using wavesurfer.js record plugin.
 * Designed purely for visualization – it never stops or alters the passed MediaStream.
 */
export default function LiveWaveform({
  stream,
  isActive,
  className,
  waveColor = '#7c3aed',
  height = 56
}: LiveWaveformProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const wavesurferRef = useRef<any>(null);
  const recordPluginRef = useRef<any>(null);
  const micCleanupRef = useRef<(() => void) | null>(null);

  // Initialise wavesurfer when a stream is available
  useEffect(() => {
    let isCancelled = false;

    if (!stream || !containerRef.current) {
      micCleanupRef.current?.();
      micCleanupRef.current = null;
      wavesurferRef.current?.destroy?.();
      wavesurferRef.current = null;
      recordPluginRef.current = null;
      return;
    }

    const setup = async () => {
      const [{ default: WaveSurfer }, { default: RecordPlugin }] = await Promise.all([
        import('wavesurfer.js'),
        import('wavesurfer.js/dist/plugins/record.esm.js')
      ]);

      if (isCancelled || !containerRef.current) {
        return;
      }

      const wavesurfer = WaveSurfer.create({
        container: containerRef.current,
        waveColor,
        progressColor: waveColor,
        barWidth: 1,
        barGap: 0,
        cursorWidth: 0,
        interact: false,
        height,
        normalize: true,
        fillParent: true,
        autoCenter: false,
        autoScroll: false,
        hideScrollbar: true
      });

      const recordPlugin = wavesurfer.registerPlugin(
        RecordPlugin.create({
          renderRecordedAudio: false,
          continuousWaveform: true,
          continuousWaveformDuration: 600
        })
      );

      wavesurferRef.current = wavesurfer;
      recordPluginRef.current = recordPlugin;
    };

    setup().catch((error) => {
      // eslint-disable-next-line no-console
      console.error('Failed to initialise live waveform', error);
    });

    return () => {
      isCancelled = true;
      micCleanupRef.current?.();
      micCleanupRef.current = null;
      recordPluginRef.current = null;
      wavesurferRef.current?.destroy?.();
      wavesurferRef.current = null;
    };
  }, [stream, waveColor, height]);

  // Bind stream to plugin when active
  useEffect(() => {
    const recordPlugin = recordPluginRef.current;

    if (!recordPlugin || !stream) {
      return;
    }

    if (isActive) {
      if (!micCleanupRef.current) {
        const micStream = recordPlugin.renderMicStream(stream);
        micCleanupRef.current = () => {
          micStream?.onDestroy?.();
        };
      } else {
        recordPlugin.isWaveformPaused = false;
      }
    } else if (micCleanupRef.current) {
      // Pause visual updates but keep the waveform mounted
      recordPlugin.isWaveformPaused = true;
    }
  }, [isActive, stream]);

  return <div ref={containerRef} className={cn('w-full overflow-hidden', className)} />;
}
